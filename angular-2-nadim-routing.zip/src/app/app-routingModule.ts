import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EmployeeListComponent } from './emp-list.component';
import { DepartmentListComponent } from './department-list.component';
import { DepartmentDetailComponent } from './department-detail.component';
import { AnimationComponent } from './animation.component';
import { HomeComponent } from './home.component';
import { PNFComponent } from './pageNotFound.component';

const routes: Routes = [
  { path: '',
    redirectTo: '/',
    pathMatch: 'full'
  },
  {  path : '', component: HomeComponent },
  {  path : 'departments', component: DepartmentListComponent },
  {  path : 'employees', component: EmployeeListComponent },
  {  path : 'animation', component: AnimationComponent },
  {  path : 'departments/:id', component: DepartmentDetailComponent },
  {  path : '**', component: PNFComponent }

];

@NgModule({
  imports:  [
      RouterModule.forRoot(routes)
         ],
  exports: [
    RouterModule
  ]

})
export class AppRoutingModule { }
export const routingComponents = [ HomeComponent, DepartmentListComponent, EmployeeListComponent, DepartmentDetailComponent, PNFComponent, AnimationComponent ];
