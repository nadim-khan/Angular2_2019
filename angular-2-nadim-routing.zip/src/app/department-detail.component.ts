import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
@Component({
  template: `<h3> You selected department detail with Id = {{deptId}}<h3>
            <a (click)="goPrevious()"><< Previous</a>  &nbsp;
            <a (click)="goNext()"> Next >></a>
            <p>
            <br/>
              <button (click)="goBack()"> <- Back </button>
            </p>
  `
})

export class DepartmentDetailComponent implements OnInit {
  public deptId;
  constructor(private route: ActivatedRoute, private router: Router) {}
  /*ngOnInit() {
    const id = this.route.snapshot.params['id'] ;
    this.deptId = id;
  }*/
  ngOnInit() {
    this.route.params.subscribe((params: Params) => {
      const id = params['id'];
      this.deptId = id;
    });
  }

  goPrevious() {
    const previousId = this.deptId - 1 ;
    this.router.navigate(['/departments', previousId] );
  }
  goNext() {
    const nextId = parseInt(this.deptId)+1;
    this.router.navigate(['/departments', nextId] );
  }
  goBack() {
    const selectedId = this.deptId ? this.deptId : null;
    this.router.navigate(['/departments', { id: selectedId }]);
  }
}
