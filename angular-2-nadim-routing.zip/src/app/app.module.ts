import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routingModule';
import { AppComponent } from './app.component';
import { routingComponents } from './app-routingModule';


@NgModule({
  imports:  [ 
      BrowserModule,
       FormsModule,
       AppRoutingModule,
       BrowserAnimationsModule
         ],
 /* declarations: [ AppComponent, EmployeeListComponent, DepartmentListComponent ], */
  declarations: [ AppComponent, routingComponents ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
