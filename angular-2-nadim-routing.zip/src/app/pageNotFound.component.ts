import { Component, OnInit } from '@angular/core';

@Component({
  template: `<H3> Page Not Found !! </H3>
              <h4> URL you entered doesnt exist</h4> `,
  styles: []
})
export class PNFComponent implements OnInit {

  constructor() { }
  ngOnInit() {
  }
}
