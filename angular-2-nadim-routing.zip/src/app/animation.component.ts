import { Component, OnInit } from '@angular/core';
import { trigger, state, style, transition, animate, keyframes, group } from '@angular/animations';

@Component({
  selector: 'my-animation',
  template: `  <h1> {{title}} </h1>
  <table >
    <tr>
      <th align= "center">
        <button class="button" (click)="toggleLights()"><span>Toggle Light</span></button>     
      </th>
      <th align= "center">
        <button class="button" (click)="toggleHights()"><span>Toggle  Height</span></button>
      </th>
      <th align= "center">
        <button class="button" (click)="toggleGroup()"><span>Toggle Now </span> </button>
      </th>
      <th align= "center">
        <button class="button" (click)="flyText()" ><span>Toggle It  </span></button>
      </th>
      <th align= "center">
        <button class="button" (click)="keyF()"><span>Toggle Final</span></button>     
      </th>
    </tr>
    <tr>
      <td>
        <div class="room" (@lightsOnOff.start)="onStart($event)" (@lightsOnOff.done)="onDone($event)" [@lightsOnOff]="roomState">
               <br/>
               <p align= "center" style="color: Black"> Light is ON now </p><br/>
               <p align= "center" style="color: yellow"> Light is Off now </p>
                </div>
      </td>
      <td>
        <div class="heightbox"  [@calcHeight]="heightState">
                <br/>
                <br/>
                <p align="center" style="color: white">This is  the Actual height</p>
                <br/>
                <br/>                
                
                </div>
      </td>
      <td>
        <div class="room"  [@groupOnOff]="otherState"><br/>
                <p align= "center" style="color: Black"> Light is ON now </p><br/>
               <p align= "center" style="color: yellow"> Light is Off now </p>
               </div>
      </td>
      <td>
        <div *ngIf="showDiv" [@flyInOut] class="flyInOut"> Text fly In Out</div>
      </td>
      <td>
        <div *ngIf="showDiv2" [@KeyFrame] class="keyF"> MMove Keyframe</div>
      </td>
      
    </tr>
  </table>

              
               `,
  styleUrls: [ './app.component.css' ],
  animations: [
    trigger('lightsOnOff', [
      state('off', style({
        backgroundColor: 'black'
      })),
      state('on', style({
        backgroundColor: 'yellow'
      })),
      transition('off => on, on => off', [animate('1s ease-out')])
    ]),

    trigger('calcHeight', [
      state('short', style({
        height: '32px'
      })),
      state('fullon', style({
        height: '*'
      })),
      transition('short <=> full', [animate('1s ease-in')])
    ]),

    trigger('groupOnOff', [
      state('off', style({
        backgroundColor: 'black'
      })),
      state('on', style({
        backgroundColor: 'yellow'
      })),
      transition('off=>on',[group([
        animate('3s ease-in',style({
          transform:'rotate(90deg)'
        })),
        animate('1s ease-out',style({
          width: '50px'
        }))
      ])]),
      transition('on=>off',[group([
        animate('3s ease-out',style({
          transform:'rotate(360deg)'
        })),
        animate('2s 1s ease-in',style({
          backgroundColor:'lightgreen'
        }))
      ])])
    ]),

    trigger('flyInOut', [      
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),
      animate('0.5s')
      ]),
    transition('* => void', [
      animate('1s', style({ transform: 'translateX(100%)' }))
    ])
  ]),

  trigger('KeyFrame', [      
      transition('void => *', [
        style({ transform: 'translateX(-100%)' }),
      animate(1000,keyframes([
        style({opacity:0, transform:'translateX(-100%)',offset:0}),
        style({opacity:1, transform:'translateX(15px)',offset:0.3}),
        style({opacity:1, transform:'translateX(0)',offset:1})
      ]))
      ]),
    transition('* => void', [
      animate(2000, keyframes([
        style({opacity:1, transform:'translateX(0)',offset:0}),
        style({opacity:1, transform:'translateX(-15px)',offset:0.7}),
        style({opacity:0, transform:'translateX(100%)',offset:1}),
        style({opacity:0, transform:'translatez(100%)',offset:1.2}),
        style({opacity:1, transform:'translateY(-75px)',offset:1.7}),
        style({opacity:0, transform:'translateY(100%)',offset:2})
      ]))
    ])
  ])
  ]
})
export class AnimationComponent implements OnInit {
  title = 'Angular Animations';
 roomState = 'off';
 heightState = 'short';
 otherState = 'off';
 showDiv= true;
 showDiv2= true;
 ngOnInit() {

 }
 toggleLights() {
   this.roomState = (this.roomState === 'off' ) ? 'on' : 'off' ;
 }
 toggleHights() {
   this.heightState = (this.heightState === 'short' ) ? 'full' : 'short' ;
 }
 toggleGroup() {
   this.otherState = (this.otherState === 'off' ) ? 'on' : 'off' ;
 }
 flyText(){
   this.showDiv= this.showDiv ? false : true;
 }
 keyF(){
   this.showDiv2= this.showDiv2 ? false : true;
 }
 onStart(event: any){
   console.log('Event Started');
   console.log('From State : '+ event.fromState);
   console.log('To State : '+ event.toState);
   console.log('Time Elapsed : '+ event.totalTime+'ms');
 }
 onDone(event: any){
   console.log('From State : '+ event.fromState);
   console.log('To State : '+ event.toState);
   console.log('Time Elapsed : '+ event.totalTime+'ms');
   console.log('Event Completed');
 }
}
