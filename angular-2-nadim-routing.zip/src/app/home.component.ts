import { Component, OnInit } from '@angular/core';

@Component({
  template: `<H3> Welcome to Angular Routing</H3> `,
  styles: []
})
export class HomeComponent implements OnInit {

  constructor() { }
  ngOnInit() {
  }
}
